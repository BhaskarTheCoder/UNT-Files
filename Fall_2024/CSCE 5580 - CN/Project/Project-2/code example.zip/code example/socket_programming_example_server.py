# Socket programming example: server side config.
import socket
