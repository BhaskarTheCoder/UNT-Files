import java.sql.*;

public class LibraryDatabase {
    private Connection connection;

    public LibraryDatabase() {
        // Initialize database connection
        this.connection = connect();
    }

    private Connection connect() {
        // This method would handle making the connection to the database
        // You would typically load the JDBC driver, then connect to the DB
        Connection conn = null;
        String url = "jdbc:mysql://your_database_url/librarydb";
        String user = "your_username";
        String password = "your_password";
        try {
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public boolean addBook(String isbn, String title, String author, String genre, int publicationYear) {
        String sql = "INSERT INTO Books (ISBN, Title, Author, Genre, PublicationYear) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, isbn);
            statement.setString(2, title);
            statement.setString(3, author);
            statement.setString(4, genre);
            statement.setInt(5, publicationYear);

            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean addBookCopies(String isbn, int numberOfCopies) {
        String sql = "INSERT INTO BookCopies (ISBN, AvailabilityStatus) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            int rowsInserted = 0;
            for (int i = 0; i < numberOfCopies; i++) {
                statement.setString(1, isbn);
                statement.setBoolean(2, true); // New copies are assumed to be available by default
                rowsInserted += statement.executeUpdate();
            }
            return rowsInserted == numberOfCopies;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}


