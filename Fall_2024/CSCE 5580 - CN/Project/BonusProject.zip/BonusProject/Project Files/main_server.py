from socket_programming_example_server import socket_example_server

def main():
    print("Starting the server...")
    socket_example_server()  

if __name__ == "__main__":
    main()
