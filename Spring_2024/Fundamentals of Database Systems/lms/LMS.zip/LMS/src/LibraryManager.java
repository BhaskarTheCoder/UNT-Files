public class LibraryManager {
    public static void main(String[] args) {
        LibraryDatabase db = new LibraryDatabase();

        // Add a new book to the system
        boolean bookAdded = db.addBook("978-3-16-148410-0", "Sample Book", "John Doe", "Fiction", 2021);
        if (bookAdded) {
            System.out.println("Book successfully added!");
        } else {
            System.out.println("Failed to add book.");
        }

        // Add multiple copies for the new book
        boolean copiesAdded = db.addBookCopies("978-3-16-148410-0", 5); // Add 5 new copies
        if (copiesAdded) {
            System.out.println("Copies successfully added!");
        } else {
            System.out.println("Failed to add copies.");
        }
    }
}