import socket

def socket_example_client():
    # Define server parameters
    host = '127.0.0.1'  # Localhost
    port = 65432        # Port to connect to

    # Create a socket object
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        # Connect to the server
        client_socket.connect((host, port))
        print(f"Connected to server at {host}:{port}")

        # Send a message
        message = "Hello, Server!"
        client_socket.sendall(message.encode('utf-8'))

        # Receive the server's response
        data = client_socket.recv(1024)
        print(f"Received from server: {data.decode('utf-8')}")
