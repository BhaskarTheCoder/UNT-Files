import socket

def socket_example_server():
    # Define server parameters
    host = '127.0.0.1'  # Localhost
    port = 65432        # Arbitrary non-privileged port

    # Create a socket object
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        # Bind to the address
        server_socket.bind((host, port))
        print(f"Server started at {host}:{port}")

        # Start listening for connections
        server_socket.listen(1)
        print("Waiting for a connection...")

        # Accept a connection
        conn, addr = server_socket.accept()
        with conn:
            print(f"Connected by {addr}")

            # Receive data
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                print(f"Received: {data.decode('utf-8')}")

                # Echo back the received data
                conn.sendall(data)
