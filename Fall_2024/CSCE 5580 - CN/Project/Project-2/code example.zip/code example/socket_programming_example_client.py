# Socket programming example: client side config.
import socket

