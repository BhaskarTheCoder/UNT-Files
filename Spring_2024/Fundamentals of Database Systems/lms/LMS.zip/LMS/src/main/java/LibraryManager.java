public class LibraryManager {
    public static void main(String[] args) {
        LibraryService db = new LibraryService();
        AuthenticationService authService  = new AuthenticationService();
        CommandLineInterface commandLineInterface = new CommandLineInterface(db,authService);
        commandLineInterface.start();
    }
}
