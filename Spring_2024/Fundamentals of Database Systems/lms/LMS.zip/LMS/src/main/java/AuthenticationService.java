import java.util.HashMap;
import java.util.Map;

public class AuthenticationService {
    private Map<String, User> users; // This should be replaced by a proper user management system.
    private User currentUser;

    public AuthenticationService() {
        this.users = new HashMap<>();
        // In a real application, replace this with a database or another secure storage method
        this.users.put("admin", new User("admin", "adminpass", "admin",100));
        this.users.put("borrower", new User("borrower", "borrowerpass", "borrower",200));
    }

    public boolean login(String username, String password) {
        // Authentication logic - in a real-world app, securely check password with hashed value.
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            this.currentUser = user;
            return true;
        }
        return false;
    }

    public void logout() {
        this.currentUser = null;
    }

    public User getCurrentUser() {
        return currentUser;
    }
}
