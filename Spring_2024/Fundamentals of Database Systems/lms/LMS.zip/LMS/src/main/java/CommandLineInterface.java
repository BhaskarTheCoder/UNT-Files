import java.util.Scanner;

public class CommandLineInterface {
    private Scanner scanner;
    private AuthenticationService authService;
    private LibraryService db;

    public CommandLineInterface(LibraryService db, AuthenticationService authService) {
        this.scanner = new Scanner(System.in);
        this.authService = authService;
        this.db = db;
    }

    public void start() {
        while (true) {
            System.out.println("Welcome to the Library Management System!");
            System.out.println("1. Login");
            System.out.println("2. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    login();
                    break;
                case 2:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private void login() {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (authService.login(username, password)) {
            User user = authService.getCurrentUser();
            if ("admin".equals(user.getRole())) {
                showAdminMenu();
            } else {
                showBorrowerMenu();
            }
        } else {
            System.out.println("Login failed!");
        }
    }

    private void showAdminMenu() {
        boolean exit = false;
        while (!exit) {
            System.out.println("\nAdmin Menu:");
            System.out.println("1. Add Book");
            System.out.println("2. Add BookCopies");
            System.out.println("3. Add Borrower");
            System.out.println("4. Borrow Book");
            System.out.println("5. Return Book");
            System.out.println("6. Search Books");
            System.out.println("7. View Borrowing History");
            System.out.println("8. Logout");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    db.addBook(); // Implement this method in LibraryService
                    break;
                case 2:
                    db.addBookCopies(); // Implement this method in LibraryService
                    break;
                case 3:
                    db.addBorrower(); // Implement this method in LibraryService
                    break;
                case 4:
                    db.borrowBook();  // Implement this method in LibraryService
                    break;
                case 5:
                    db.returnBook(); // Implement this method in LibraryService
                    break;
                case 6:
                    db.searchBooks(); // Implement this method in LibraryService
                    break;
                case 7:
                    db.viewBorrowingHistory(); // Implement this method in LibraryService
                    break;
                case 8:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    private void showBorrowerMenu() {
        boolean exit = false;
        int borrowerId = authService.getCurrentUser().getId(); // Assuming User class has this method.

        while (!exit) {
            System.out.println("\nBorrower Menu:");
            System.out.println("1. Search Books");
            System.out.println("2. View My Borrowing History");
            System.out.println("3. Logout");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    db.searchBooks();
                    break;
                case 2:
                    db.viewBorrowingHistory();
                    break;
                case 3:
                    exit = true;
                    authService.logout(); // Assuming logout method is available to reset current user.
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }



}
