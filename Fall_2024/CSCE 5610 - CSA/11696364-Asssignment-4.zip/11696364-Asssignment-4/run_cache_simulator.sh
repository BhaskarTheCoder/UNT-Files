#!/bin/bash

# Create output directory if it doesn't exist
mkdir -p output

# Function to run Dinero IV tests for a specific trace
run_trace_tests() {
    local trace_file=$1

    # L1 Cache Configurations without L2
    echo "# L1 Cache Tests without L2 for $trace_file #"
    
    # 16KB, 32B, 1-way
    echo "## 16KB, 32B, 1-way L1 Cache ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 32 -l1-isbsize 32 -l1-iassoc 1 \
               -l1-dsize 16K -l1-dbsize 32 -l1-dsbsize 32 -l1-dassoc 1 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_32b_1way.txt"

    # 16KB, 32B, 2-way
    echo "## 16KB, 32B, 2-way L1 Cache ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 32 -l1-isbsize 32 -l1-iassoc 2 \
               -l1-dsize 16K -l1-dbsize 32 -l1-dsbsize 32 -l1-dassoc 2 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_32b_2way.txt"

    # 16KB, 32B, 4-way
    echo "## 16KB, 32B, 4-way L1 Cache ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 32 -l1-isbsize 32 -l1-iassoc 4 \
               -l1-dsize 16K -l1-dbsize 32 -l1-dsbsize 32 -l1-dassoc 4 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_32b_4way.txt"

    # 16KB, 64B, 1-way
    echo "## 16KB, 64B, 1-way L1 Cache ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 64 -l1-isbsize 64 -l1-iassoc 1 \
               -l1-dsize 16K -l1-dbsize 64 -l1-dsbsize 64 -l1-dassoc 1 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_64b_1way.txt"

    # 16KB, 64B, 2-way
    echo "## 16KB, 64B, 2-way L1 Cache ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 64 -l1-isbsize 64 -l1-iassoc 2 \
               -l1-dsize 16K -l1-dbsize 64 -l1-dsbsize 64 -l1-dassoc 2 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_64b_2way.txt"

    # 16KB, 64B, 4-way
    echo "## 16KB, 64B, 4-way L1 Cache ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 64 -l1-isbsize 64 -l1-iassoc 4 \
               -l1-dsize 16K -l1-dbsize 64 -l1-dsbsize 64 -l1-dassoc 4 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_64b_4way.txt"

    # L1 and L2 Cache Configurations
    echo "# L1 and L2 Cache Tests for $trace_file #"
    
    # 16KB L1, 128KB L2, 32B, 1-way
    echo "## 16KB L1, 128KB L2, 32B, 1-way ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 32 -l1-isbsize 32 -l1-iassoc 1 \
               -l1-dsize 16K -l1-dbsize 32 -l1-dsbsize 32 -l1-dassoc 1 \
               -l2-usize 128K -l2-ubsize 32 -l2-usbsize 32 -l2-uassoc 1 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_128k_32b_1way.txt"

    # 16KB L1, 128KB L2, 32B, 2-way
    echo "## 16KB L1, 128KB L2, 32B, 2-way ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 32 -l1-isbsize 32 -l1-iassoc 2 \
               -l1-dsize 16K -l1-dbsize 32 -l1-dsbsize 32 -l1-dassoc 2 \
               -l2-usize 128K -l2-ubsize 32 -l2-usbsize 32 -l2-uassoc 2 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_128k_32b_2way.txt"

    # 16KB L1, 128KB L2, 32B, 4-way
    echo "## 16KB L1, 128KB L2, 32B, 4-way ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 32 -l1-isbsize 32 -l1-iassoc 4 \
               -l1-dsize 16K -l1-dbsize 32 -l1-dsbsize 32 -l1-dassoc 4 \
               -l2-usize 128K -l2-ubsize 32 -l2-usbsize 32 -l2-uassoc 4 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_128k_32b_4way.txt"

    # 16KB L1, 128KB L2, 64B, 1-way
    echo "## 16KB L1, 128KB L2, 64B, 1-way ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 64 -l1-isbsize 64 -l1-iassoc 1 \
               -l1-dsize 16K -l1-dbsize 64 -l1-dsbsize 64 -l1-dassoc 1 \
               -l2-usize 128K -l2-ubsize 64 -l2-usbsize 64 -l2-uassoc 1 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_128k_64b_1way.txt"

    # 16KB L1, 128KB L2, 64B, 2-way
    echo "## 16KB L1, 128KB L2, 64B, 2-way ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 64 -l1-isbsize 64 -l1-iassoc 2 \
               -l1-dsize 16K -l1-dbsize 64 -l1-dsbsize 64 -l1-dassoc 2 \
               -l2-usize 128K -l2-ubsize 64 -l2-usbsize 64 -l2-uassoc 2 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_128k_64b_2way.txt"

    # 16KB L1, 128KB L2, 64B, 4-way
    echo "## 16KB L1, 128KB L2, 64B, 4-way ##"
    ./dineroIV -l1-isize 16K -l1-ibsize 64 -l1-isbsize 64 -l1-iassoc 4 \
               -l1-dsize 16K -l1-dbsize 64 -l1-dsbsize 64 -l1-dassoc 4 \
               -l2-usize 128K -l2-ubsize 64 -l2-usbsize 64 -l2-uassoc 4 \
               -informat d < "$trace_file" > "output/results_$(basename "$trace_file" .din)_16k_128k_64b_4way.txt"
}

# Main execution for all traces
run_trace_tests "Trace1.din"
run_trace_tests "Trace2.din"
run_trace_tests "Trace3.din"

