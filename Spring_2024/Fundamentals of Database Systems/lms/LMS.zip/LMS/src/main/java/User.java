public class User {
    private String username;
    private String password; // Store hashed passwords in a real application
    private String role;
    private int id;

    public User(String username, String password, String role, int id) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.id = id;
    }

    // Getters and potentially setters depending on your needs
    public String getUsername() {
        return username;
    }

    public int getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }
}
