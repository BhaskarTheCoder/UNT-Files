import java.sql.*;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.*;


public class LibraryService {
    private Connection connection;
    private Scanner scanner;
    public LibraryService() {
        // Initialize database connection
        this.connection = connect();
        this.scanner = new Scanner(System.in);
    }

    private Connection connect() {
        // This method would handle making the connection to the database
        // You would typically load the JDBC driver, then connect to the DB
        Connection conn = null;
        String url = "jdbc:mysql://localhost:3306/lms";
        String user = "root";
        String password = "";
        try {
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
    public void addBook() {
        System.out.println("Add a new book");
        System.out.print("Enter ISBN: ");
        String isbn = scanner.nextLine();

        System.out.print("Enter Title: ");
        String title = scanner.nextLine();

        System.out.print("Enter Author: ");
        String author = scanner.nextLine();

        System.out.print("Enter Genre: ");
        String genre = scanner.nextLine();

        System.out.print("Enter Publication Year: ");
        int publicationYear;
        try {
            publicationYear = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Publication year needs to be an integer.");
            return;
        }

        boolean bookAdded = addNewBook(isbn, title, author, genre, publicationYear);
        if (bookAdded) {
            System.out.println("Book successfully added to the system.");
        } else {
            System.out.println("Failed to add the book to the system.");
        }
    }


    public boolean addNewBook(String isbn, String title, String author, String genre, int publicationYear) {
        String sql = "INSERT INTO Books (ISBN, Title, Author, Genre, PublicationYear) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, isbn);
            statement.setString(2, title);
            statement.setString(3, author);
            statement.setString(4, genre);
            statement.setInt(5, publicationYear);

            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void addBookCopies() {
        System.out.println("Add copies of a book");
        System.out.print("Enter ISBN of the book: ");
        String isbn = scanner.nextLine();

        System.out.print("Enter the number of copies to add: ");
        int numberOfCopies;
        try {
            numberOfCopies = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Number of copies needs to be an integer.");
            return;
        }

        boolean copiesAdded = addBookCopies(isbn, numberOfCopies);
        if (copiesAdded) {
            System.out.println(numberOfCopies + " copies successfully added for ISBN " + isbn);
        } else {
            System.out.println("Failed to add copies for ISBN " + isbn);
        }
    }


    public boolean addBookCopies(String isbn, int numberOfCopies) {
        String sql = "INSERT INTO BookCopies (ISBN, AvailabilityStatus) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            int rowsInserted = 0;
            for (int i = 0; i < numberOfCopies; i++) {
                statement.setString(1, isbn);
                statement.setBoolean(2, true); // New copies are assumed to be available by default
                rowsInserted += statement.executeUpdate();
            }
            return rowsInserted == numberOfCopies;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void addBorrower() {
        System.out.println("Add a new borrower to the system");

        System.out.print("Enter borrower's name: ");
        String name = scanner.nextLine();

        System.out.print("Enter borrower's email: ");
        String email = scanner.nextLine();

        System.out.print("Enter borrower's contact number: ");
        String contactNumber = scanner.nextLine();

        boolean isRegistered = registerNewBorrower(name, email, contactNumber);
        if (isRegistered) {
            System.out.println("New borrower added successfully.");
        } else {
            System.out.println("Failed to add the new borrower.");
        }
    }

    public boolean registerNewBorrower(String name, String email, String contactNumber) {
            String sql = "INSERT INTO Borrowers (Name, Email, ContactNumber) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, email);
                statement.setString(3, contactNumber);

                int rowsInserted = statement.executeUpdate();
                return rowsInserted > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
    }

    public void borrowBook() {
        System.out.println("Process a book borrowing");

        System.out.print("Enter Borrower ID: ");
        int borrowerId = scanner.nextInt();
        scanner.nextLine();  // Flush the newline

        System.out.print("Enter Book ISBN: ");
        String isbn = scanner.nextLine();

        System.out.print("Enter Borrowing Date (YYYY-MM-DD): ");
        String borrowingDate = scanner.nextLine();

        boolean isBorrowed = processBookBorrowing(borrowerId, isbn, borrowingDate);
        if (isBorrowed) {
            System.out.println("Book borrowing processed successfully.");
        } else {
            System.out.println("Failed to process book borrowing.");
        }
    }

    public boolean processBookBorrowing(int borrowerId, String isbn, String borrowingDate) {
            // Start a transaction
            try {
                connection.setAutoCommit(false); // Disable auto-commit for transaction

                // Step 1: Check if there is an available copy
                String checkCopySQL = "SELECT SerialNumber FROM BookCopies WHERE ISBN = ? AND AvailabilityStatus = TRUE LIMIT 1";
                int serialNumber = -1;
                try (PreparedStatement checkCopyStmt = connection.prepareStatement(checkCopySQL)) {
                    checkCopyStmt.setString(1, isbn);
                    ResultSet resultSet = checkCopyStmt.executeQuery();
                    if (resultSet.next()) {
                        serialNumber = resultSet.getInt("SerialNumber");
                    } else {
                        connection.rollback(); // No available copy found, rollback transaction
                        return false;
                    }
                }

                // Step 2: Insert a new row into Transactions
                String transactionSQL = "INSERT INTO Transactions (BorrowerID, SerialNumber, BorrowingDate) VALUES (?, ?, ?)";
                try (PreparedStatement transactionStmt = connection.prepareStatement(transactionSQL)) {
                    transactionStmt.setInt(1, borrowerId);
                    transactionStmt.setInt(2, serialNumber);
                    transactionStmt.setDate(3, Date.valueOf(borrowingDate));
                    transactionStmt.executeUpdate();
                }

                // Step 3: Update the book copy's availability status
                String updateCopySQL = "UPDATE BookCopies SET AvailabilityStatus = FALSE WHERE SerialNumber = ?";
                try (PreparedStatement updateCopyStmt = connection.prepareStatement(updateCopySQL)) {
                    updateCopyStmt.setInt(1, serialNumber);
                    updateCopyStmt.executeUpdate();
                }

                connection.commit(); // Commit the transaction
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
                try {
                    connection.rollback(); // Rollback the transaction on error
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
                return false;
            } finally {
                try {
                    connection.setAutoCommit(true); // Restore auto-commit mode
                } catch (SQLException finalEx) {
                    finalEx.printStackTrace();
                }
            }
        }


    public void returnBook() {
        System.out.println("Process a book return");

        System.out.print("Enter Transaction ID of the borrowing record: ");
        int transactionId = scanner.nextInt(); // Make sure to handle InputMismatchException
        scanner.nextLine(); // Flush the newline

        System.out.print("Enter Return Date (YYYY-MM-DD): ");
        String returnDate = scanner.nextLine();

        boolean isReturned = processBookReturning(transactionId, returnDate);
        if (isReturned) {
            System.out.println("Book return processed successfully.");
        } else {
            System.out.println("Failed to process book return.");
        }
    }

    public boolean processBookReturning(int transactionId, String returnDate) {
            // Start a transaction
            try {
                connection.setAutoCommit(false); // Disable auto-commit for transaction

                // Step 1: Retrieve the SerialNumber of the book copy based on the transactionId
                String getCopySQL = "SELECT SerialNumber FROM Transactions WHERE TransactionID = ?";
                int serialNumber = -1;
                try (PreparedStatement getCopyStmt = connection.prepareStatement(getCopySQL)) {
                    getCopyStmt.setInt(1, transactionId);
                    ResultSet resultSet = getCopyStmt.executeQuery();
                    if (resultSet.next()) {
                        serialNumber = resultSet.getInt("SerialNumber");
                    } else {
                        connection.rollback(); // No borrowing record found, rollback transaction
                        return false;
                    }
                }

                // Step 2: Update the return date in Transactions
                String updateTransactionSQL = "UPDATE Transactions SET ReturnDate = ? WHERE TransactionID = ?";
                try (PreparedStatement updateTransactionStmt = connection.prepareStatement(updateTransactionSQL)) {
                    updateTransactionStmt.setDate(1, Date.valueOf(returnDate));
                    updateTransactionStmt.setInt(2, transactionId);
                    updateTransactionStmt.executeUpdate();
                }

                // Step 3: Update the book copy's availability status
                String updateCopySQL = "UPDATE BookCopies SET AvailabilityStatus = TRUE WHERE SerialNumber = ?";
                try (PreparedStatement updateCopyStmt = connection.prepareStatement(updateCopySQL)) {
                    updateCopyStmt.setInt(1, serialNumber);
                    updateCopyStmt.executeUpdate();
                }

                connection.commit(); // Commit the transaction
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
                try {
                    connection.rollback(); // Rollback the transaction on error
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
                return false;
            } finally {
                try {
                    connection.setAutoCommit(true); // Restore auto-commit mode
                } catch (SQLException finalEx) {
                    finalEx.printStackTrace();
                }
            }
        }

    public void searchBooks() {
        System.out.println("Search for books");

        System.out.print("Enter search keyword: ");
        String keyword = scanner.nextLine();

        List<Map<String, Object>> foundBooks = searchBooksLogic(keyword);
        if (foundBooks.isEmpty()) {
            System.out.println("No books found matching the criteria.");
        } else {
            System.out.println("Found books:");
            for (Map<String, Object> book : foundBooks) {
                System.out.println("ISBN: " + book.get("ISBN") +
                        ", Title: " + book.get("Title") +
                        ", Author: " + book.get("Author") +
                        ", Genre: " + book.get("Genre") +
                        ", Publication Year: " + book.get("PublicationYear") +
                        ", Serial Number: " + book.get("SerialNumber") +
                        ", Available: " + book.get("AvailabilityStatus"));
            }
        }
    }

    public List<Map<String, Object>> searchBooksLogic(String keyword) {
            List<Map<String, Object>> results = new ArrayList<>();
            String sql = "SELECT b.*, bc.SerialNumber, bc.AvailabilityStatus " +
                    "FROM Books b " +
                    "JOIN BookCopies bc ON b.ISBN = bc.ISBN " +
                    "WHERE b.ISBN LIKE ? OR b.Title LIKE ? OR b.Author LIKE ? " +
                    "OR b.Genre LIKE ? OR CAST(b.PublicationYear AS CHAR) LIKE ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                String searchKeyword = "%" + keyword + "%";
                statement.setString(1, searchKeyword);
                statement.setString(2, searchKeyword);
                statement.setString(3, searchKeyword);
                statement.setString(4, searchKeyword);
                statement.setString(5, searchKeyword);

                ResultSet rs = statement.executeQuery();
                while (rs.next()) {
                    Map<String, Object> bookData = new HashMap<>();
                    bookData.put("ISBN", rs.getString("ISBN"));
                    bookData.put("Title", rs.getString("Title"));
                    bookData.put("Author", rs.getString("Author"));
                    bookData.put("Genre", rs.getString("Genre"));
                    bookData.put("PublicationYear", rs.getInt("PublicationYear"));
                    bookData.put("SerialNumber", rs.getInt("SerialNumber"));
                    bookData.put("AvailabilityStatus", rs.getBoolean("AvailabilityStatus"));
                    results.add(bookData);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return results;
        }

    public List<Map<String, Object>> viewBorrowingHistorySQL(int borrowerId) {
            List<Map<String, Object>> history = new ArrayList<>();
            String sql = "SELECT t.TransactionID, t.SerialNumber, t.BorrowingDate, t.ReturnDate, b.Title " +
                    "FROM Transactions t " +
                    "JOIN BookCopies bc ON t.SerialNumber = bc.SerialNumber " +
                    "JOIN Books b ON bc.ISBN = b.ISBN " +
                    "WHERE t.BorrowerID = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, borrowerId);
                try (ResultSet rs = statement.executeQuery()) {
                    while (rs.next()) {
                        Map<String, Object> record = new HashMap<>();
                        record.put("TransactionID", rs.getInt("TransactionID"));
                        record.put("SerialNumber", rs.getInt("SerialNumber"));
                        record.put("BorrowingDate", rs.getDate("BorrowingDate"));
                        record.put("ReturnDate", rs.getDate("ReturnDate"));
                        record.put("Title", rs.getString("Title"));
                        history.add(record);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return history;
        }

    public void viewBorrowingHistory() {
        System.out.print("Enter Borrower ID to view borrowing history: ");
        int borrowerId = scanner.nextInt();
        scanner.nextLine();  // to consume the rest of the line

        List<Map<String, Object>> history = viewBorrowingHistorySQL(borrowerId);
        if (history.isEmpty()) {
            System.out.println("No borrowing history found for the borrower with ID " + borrowerId);
        } else {
            System.out.println("Borrowing history for borrower ID " + borrowerId + ":");
            for (Map<String, Object> transaction : history) {
                System.out.println("Transaction ID: " + transaction.get("TransactionID") +
                        ", Serial Number: " + transaction.get("SerialNumber") +
                        ", Book Title: " + transaction.get("Title") +
                        ", Borrowing Date: " + transaction.get("BorrowingDate") +
                        ", Return Date: " + transaction.get("ReturnDate"));
            }
        }
    }










}
